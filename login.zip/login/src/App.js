import "./styles.css";
import React, { useReducer, useEffect, useRef } from "react";
import { reducer } from "./reducer";
export default function App() {
  var text = "nothing";
  const [response, dispatch] = useReducer(reducer, null);
  const [username, dispatchUserName] = useReducer(reducer, text);
  const [password, dispatchPassword] = useReducer(reducer, text);

  const initLogin = async () => {
    console.log("username" + username);
    const loginData = {
      username: username,
      password: password
    };
    console.log("username" + username);
    console.log("password" + password);
    await dispatch({
      type: "3",
      content: loginData
    });
  };
  const onChangeUsername = (e) => {
    console.log("username" + e.target.value);
    dispatchUserName({
      type: "1",
      content: e.target.value
    });
  };

  const onChangePassword = (e) => {
    console.log("password" + e.target.value);
    dispatchPassword({
      type: "2",
      content: e.target.value
    });
  };
  const login = async () => {
    initLogin();
  };

  useEffect(() => {
    if (response) {
      if (response.status === 200) {
        alert("login successful");
      } else if (response.status === 400) {
        alert("login failed");
      }
    }
  }, [response]);

  return (
    <div className="App">
      <label>Username</label>
      <input type="text" onChange={onChangeUsername} />
      <br />
      <br />
      <label>Password</label>
      <input type="text" onChange={onChangePassword} />
      <br />
      <br />
      <button onClick={login}>Login</button>
    </div>
  );
}
