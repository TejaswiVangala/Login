export const reducer = (state, action) => {
  console.log(state + action.type + action.content);
  const user = { username: "teja", password: "1234" };
  switch (action.type) {
    case "1":
      return action.content;
    case "2":
      return action.content;
    case "3":
      console.log(
        "username .. password" +
          action.content.username +
          action.content.password
      );

      if (
        action.content.username === user.username &&
        action.content.password === user.password
      ) {
        return {
          id: Math.random(),
          status: 200
        };
      } else {
        return {
          id: Math.random(),
          status: 400
        };
      }

    default:
      return state;
  }
};
